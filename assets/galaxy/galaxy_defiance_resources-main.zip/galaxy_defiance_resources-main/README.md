# galaxy_defiance_resources

This is a repository to hold the resources for my new YouTube tutorial series in Godot 4. In the series you'll learn to make a simple Space Shooter game using components (Godot's custom nodes).

The sprites were done by GrafxKid and are under a CCO license.
https://opengameart.org/content/arcade-space-shooter-game-assets

The font was done by Kenney and is also under a CCO license.
https://kenney.nl/assets/kenney-fonts

The sound effects were made by me and are under a CCO license.

The script files are all under an MIT license.
